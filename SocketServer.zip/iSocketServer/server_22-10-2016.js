var express = require('express');
var app 	= express();
var server 	= require('http').createServer(app);
var io 		= require('socket.io')(server);
var Promise = require('promise');
var moment 	= require('moment');

var port = process.env.PORT || 3001;

server.listen(port, function () {
	console.log('Socket Server listening at port %d', port);
});

//var socket = require('socket.io-client')('http://localhost');
//socket.on('connect', function(){});
//socket.on('event', function(data){});
//socket.on('disconnect', function(){});


// Routing
app.use(express.static(__dirname + '/public'));


var numUsers = 0;
var username;
var connected = false;

io.on('connection', function (socket) {
	var addedUser = false;
	
	socket.on('vehicleMovementUpdateRequest', function (data) {
		console.log('Update request received!');
		console.log(data);
		if( isValidJSON(data) ) {
			updateVehicleMovement(socket, JSON.parse(data));
		}
		else {
			console.log('vehicle movement update error - event occured (JSON Validation Failed)');
			socket.emit('vehicleMovementUpdateError', {
				status 			: 'error',
				error			: true,
				message			: 'JSON Validation Failed!', 
				request_data 	: data,
				response_data	: false,
				request_user	: socket.username
			});		
		}
	});	
	
	socket.on('vehicleMovementReadRequest', function (data) {
		console.log('Read request received!');
		console.log(data);
		if( isValidJSON(data) ) {
			readVehicleMovement(socket, JSON.parse(data));
		}
		else {
			console.log('vehicle movement read request error - event occured (JSON Validation Failed)');
			socket.emit('vehicleMovementReadError', {
				status 			: 'error',
				error			: true,
				message			: 'JSON Validation Failed!', 
				request_data 	: data,
				response_data	: false,
				request_user	: socket.username
			});		
		}
	});		
	
	// when the client emits 'add user', this listens and executes
	socket.on('addUser', function (username) {
		console.log(username);
		if (addedUser) return;
		
		// we store the username in the socket session for this client
		socket.username = username;
		++numUsers;
		addedUser = true;
		
		console.log("New User Added with username: " + username);
		console.log("Total Users: " + numUsers);
		
		socket.emit('login', {
			numUsers: numUsers
		});
		
		// echo globally (all clients) that a person has connected
		socket.broadcast.emit('userJoined', {
			username: socket.username,
			numUsers: numUsers
		});
	});
	
	// when the user disconnects.. perform this
	socket.on('disconnect', function () {
		if (addedUser) {
			--numUsers;
			
			console.log("An User with username: " + socket.username + " has left");
			console.log("Total Users: " + numUsers);
			
			// echo globally that this client has left
			socket.broadcast.emit('userLeft', {
				username: socket.username,
				numUsers: numUsers
			});
		}
	});
});

// Connecting to Database
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/sbts');	

var Schema = mongoose.Schema, ObjectId = Schema.ObjectId;

var VehicleMovementLogSchema = new Schema({
	id					: Schema.ObjectId,
	route_unique_id		: { type: String, default: '' },
	vehicle_unique_id	: { type: String, default: '' },
	school_unique_id	: { type: String, default: '' },
	driver_unique_id	: { type: String, default: '' },
	lat					: { type: String, default: '' },
	lng					: { type: String, default: '' },
	date_time_added		: { type: Date, default: Date.now },
});

var VehicleMovementLogModel = mongoose.model('vehicle_movement_log', VehicleMovementLogSchema);

var updateVehicleMovement = function(socket, options) {
	console.log('Updating Vehicle Movement Log...');
	if(options != undefined && options.hasOwnProperty('vehicle_unique_id') && options.hasOwnProperty('school_unique_id') ) {
		
		var updateObject = {};
		
		updateObject = { 	
			route_unique_id		: ( (options.route_unique_id != undefined) 	? options.route_unique_id 	: '' ),
			vehicle_unique_id	: ( (options.vehicle_unique_id != undefined)? options.vehicle_unique_id : '' ),
			school_unique_id	: ( (options.school_unique_id != undefined) ? options.school_unique_id 	: '' ),
			driver_unique_id	: ( (options.driver_unique_id != undefined) ? options.driver_unique_id 	: '' ),
			lat					: ( (options.lat != undefined) 				? options.lat 				: '' ),
			lng					: ( (options.lng != undefined) 				? options.lng 				: '' ),
			// date_time_added	: moment().format('MMMM Do YYYY, h:mm:ss a'), 	// October 20th 2016, 11:34:48 am
			//date_time_added	: moment().format('YYYY-MM-DD HH:mm:ss'), 		// 2016-10-20 11:34:48 // MySQL DATETIME FORMAT
			date_time_added		: ( (options.date_time_added != undefined) 	? options.date_time_added	: moment().format('YYYY-MM-DD HH:mm:ss') ),
		};
		
		VehicleMovementLogModel.update({vehicle_unique_id: updateObject.vehicle_unique_id, school_unique_id: updateObject.school_unique_id}, updateObject, {upsert: true}, function(err, num, n){
			console.log('Ready to send response...');
			if(err){
				//throw err;
				console.log('Error!');
				console.log('vehicle movement update error - error event occured');
				socket.emit('vehicleMovementUpdateError', {
					status 			: 'error',
					error			: true,
					message			: 'Error while updating records!', 
					//request_data 	: JSON.stringify(options),
					request_data 	: options,
					response_data	: false,
					request_user	: socket.username
				});
			} 
			else {
				console.log('Read Success!');
				// we tell the client to execute 'vehicle movement updated'
				console.log('vehicle movement update response - success event occured');
				socket.broadcast.emit('vehicleMovementUpdateResponse', {
					status 			: 'succuss',
					error			: false,
					message			: 'Vehicle movement updated!',
					//request_data	: JSON.stringify(options),
					request_data	: options,
					//response_data	: JSON.stringify(updateObject),
					response_data	: updateObject,
					request_user	: socket.username
				});
			}
			console.log(num, n);
		});	
		
		return updateObject;
	} 
	else {
		return false;
	}
};
var readVehicleMovement = function(socket, options) {
	console.log('Reading Vehicle Movement Log...');
	if(options != undefined && options.school_unique_id != undefined && options.hasOwnProperty('school_unique_id') ) {

		var readObject 	= {};
		var method		= 'find';
		readObject.school_unique_id		= options.school_unique_id;
		
		// Checking for Optional Vehicle ID
		if( options.vehicle_unique_id != undefined && options.hasOwnProperty('vehicle_unique_id')) {
			readObject.vehicle_unique_id	= options.vehicle_unique_id;
			var method		= 'findOne';
		}
			
		
		VehicleMovementLogModel[method](readObject, function(err, results){
			console.log('Ready to send response...');
			if(err){
				console.log('Error!');
				console.log('vehicle movement read error - error event occured');
				socket.emit('vehicleMovementReadError', {
					status 			: 'error',
					error			: true,
					message			: 'Error while reading vehicle movement!', 
					//request_data 	: JSON.stringify(options),
					request_data 	: options,
					response_data	: false,
					request_user	: socket.username
				});
			}
			else {
				console.log('Read Success!');
				console.log('vehicle movement read response - success event occured');
				if(results) {
					var message	= 'Vehicle found!';
					//results = JSON.stringify(results);
				} else {
					var message	= 'Vehicle Not found!';
					results	= false;
				}
				socket.emit('vehicleMovementReadResponse', {
					status 			: 'succuss',
					error			: false,
					message			: message,
					//request_data	: JSON.stringify(options),
					request_data	: options,
					response_data	: results,
					request_user	: socket.username,
				});
			}
			console.log(results);
		});		
		
		return true;
	} 
	else {
		return false;
	}
};

var isValidJSON = function(str) {
    try {
        JSON.parse(str);
	} 
	catch (e) {
        return false;
	}
    return true;
}


