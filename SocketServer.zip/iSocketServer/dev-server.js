var express = require('express');
var app 	= express();
var server 	= require('http').createServer(app);
var io 		= require('socket.io')(server);
var Promise = require('promise');
var moment 	= require('moment');

var port = process.env.PORT || 3000;

server.listen(port, function () {
	console.log('Socket Server listening at port %d', port);
});

//var socket = require('socket.io-client')('http://localhost');
//socket.on('connect', function(){});
//socket.on('event', function(data){});
//socket.on('disconnect', function(){});


// Routing
app.use(express.static(__dirname + '/public'));


var numUsers = 0;
var username;
var connected = false;

io.on('connection', function (socket) {
	console.log('A User is trying to connect...');
	console.log("Total Users: " + numUsers);
	var addedUser = false;
	
	// when the client emits 'push', this listens and executes
	socket.on('new location update', function (data) {
		// we tell the client to execute 'new message'
		socket.broadcast.emit('new location update', {
			username: socket.username,
			message: data
		});
	});
	
	// read Operation 
	/*
		{
		collection/table : 'sbts_vehicle_movement_log'
		}
	*/
	
	// vehicle movement update
	/*
		{
		collection/table : 'sbts_vehicle_movement_log'
		}
	*/

	socket.on('vehicle movement update', function (data) {
		console.log('Update request received!');
		console.log(data);
		if( isValidJSON(data) ) {
			var promise = new Promise(function (resolve, reject) {
				var response = updateVehicleMovement(JSON.parse(data));
				//if (err) reject(err);
				resolve(response);
			});
			
			promise.then(function(response){
				console.log('Ready to send response...');
				console.log(JSON.stringify(response));
				if(  response != false ) {
					// we tell the client to execute 'vehicle movement updated'
					console.log('vehicle movement updated - success event occured');
					socket.broadcast.emit('vehicle movement updated', {
						status 		: 'succuss',
						error		: false,
						message		: 'Vehicle movement updated!',
						data 		: JSON.stringify(response) 
					});
				} 
				else {
					console.log('vehicle movement update error - error event occured');
					socket.emit('vehicle movement update error', {
						status 	: 'error',
						error	: true,
						message	: 'Error while updating records!', 
						data 	: data 
					});
				}
			});	
		}
		else {
			console.log('vehicle movement update error - event occured (JSON Validation Failed)');
			socket.emit('vehicle movement update error', {
				status 	: 'error',
				error	: true,
				message	: 'JSON Validation Failed!', 
				data 	: data 
			});		
		}
	});	
	
	// when the client emits 'add user', this listens and executes
	socket.on('add user', function (username) {
		console.log(username);
		if (addedUser) return;
		
		// we store the username in the socket session for this client
		socket.username = username;
		++numUsers;
		addedUser = true;
		
		console.log("New User Added with username: " + username);
		console.log("Total Users: " + numUsers);
		
		socket.emit('login', {
			numUsers: numUsers
		});
		
		// echo globally (all clients) that a person has connected
		socket.broadcast.emit('user joined', {
			username: socket.username,
			numUsers: numUsers
		});
	});
	
	// when the user disconnects.. perform this
	socket.on('disconnect', function () {
		if (addedUser) {
			--numUsers;
			
			console.log("An User with username: " + socket.username + " has left");
			console.log("Total Users: " + numUsers);
			
			// echo globally that this client has left
			socket.broadcast.emit('user left', {
				username: socket.username,
				numUsers: numUsers
			});
		}
	});
});

// Connecting to Database
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/sbts');	

var Schema = mongoose.Schema, ObjectId = Schema.ObjectId;

var VehicleMovementLogSchema = new Schema({
	id					: Schema.ObjectId,
	route_unique_id		: { type: String, default: '' },
	vehicle_unique_id	: { type: String, default: '' },
	school_unique_id	: { type: String, default: '' },
	driver_unique_id	: { type: String, default: '' },
	lat					: { type: String, default: '' },
	lng					: { type: String, default: '' },
	date_time_added		: { type: Date, default: Date.now },
});

var VehicleMovementLogModel = mongoose.model('vehicle_movement_log', VehicleMovementLogSchema);

var updateVehicleMovement = function(options) {
	console.log('Updating Vehicle Movement Log...');
	if(options != undefined && options.hasOwnProperty('vehicle_unique_id') && options.hasOwnProperty('school_unique_id') ) {
		
		var updateObject = {};
		
		updateObject = { 	
			route_unique_id		: ( (options.route_unique_id != undefined) 	? options.route_unique_id 	: '' ),
			vehicle_unique_id	: ( (options.vehicle_unique_id != undefined)? options.vehicle_unique_id : '' ),
			school_unique_id	: ( (options.school_unique_id != undefined) ? options.school_unique_id 	: '' ),
			driver_unique_id	: ( (options.driver_unique_id != undefined) ? options.driver_unique_id 	: '' ),
			lat					: ( (options.lat != undefined) 				? options.lat 				: '' ),
			lng					: ( (options.lng != undefined) 				? options.lng 				: '' ),
			// date_time_added	: moment().format('MMMM Do YYYY, h:mm:ss a'), 	// October 20th 2016, 11:34:48 am
			//date_time_added	: moment().format('YYYY-MM-DD HH:mm:ss'), 		// 2016-10-20 11:34:48 // MySQL DATETIME FORMAT
			date_time_added		: ( (options.date_time_added != undefined) 	? options.date_time_added	: moment().format('YYYY-MM-DD HH:mm:ss') ),
		};
		
		var VehicleMovementLog = new VehicleMovementLogModel();
		//VehicleMovementLog.route_unique_id 		= ( (options.route_unique_id != undefined) 	? options.route_unique_id 	: '' );
		//VehicleMovementLog.vehicle_unique_id 	= ( (options.vehicle_unique_id != undefined)? options.vehicle_unique_id : '' );
		//VehicleMovementLog.school_unique_id 	= ( (options.school_unique_id != undefined) ? options.school_unique_id 	: '' );
		//VehicleMovementLog.driver_unique_id 	= ( (options.driver_unique_id != undefined) ? options.driver_unique_id 	: '' );
		//VehicleMovementLog.lat 					= ( (options.lat != undefined) 				? options.lat 				: '' );
		//VehicleMovementLog.lng 					= ( (options.lng != undefined) 				? options.lng 				: '' );
		//VehicleMovementLog.date_time_added 		= ( (options.date_time_added != undefined) 	? options.date_time_added	: updateObject.date_time_added );
		
		//UserModel.update({ $or: [{nick: act.nick}, {hmask: act.host}] }, { $set: { lastfm: act.params } }, { upsert: true }, function(){});
		//VehicleMovementLog.findOneAndUpdate({uniqueAttr: myObj.uniqueAttr}, myObj, {upsert: true}, function(){})
		//VehicleMovementLog.findOneAndUpdate({vehicle_unique_id: updateObject.vehicle_unique_id, school_unique_id: updateObject.school_unique_id}, , 
		/*
		VehicleMovementLog.save(function(err){
			if (err) {
				console.log('Error!');
			} 
			else {
				console.log('Success!');
			}
		});
		*/
		
		VehicleMovementLogModel.update({vehicle_unique_id: updateObject.vehicle_unique_id, school_unique_id: updateObject.school_unique_id}, updateObject, {upsert: true}, function(err, num, n){
			if(err){
				//throw err;
				console.log('Error!');
			} 
			else {
				console.log('Success!');
			}
			console.log(num, n);
		});	
		
		/*
			ContactSchema.findOne({phone: request.phone}, function(err, contact) {
			if(!err) {
			if(!contact) {
			contact = new ContactSchema();
			contact.phone = request.phone;
			}
			contact.status = request.status;
			contact.save(function(err) {
			if(!err) {
			console.log("contact " + contact.phone + " created at " + contact.createdAt + " updated at " + contact.updatedAt);
			}
			else {
			console.log("Error: could not save contact " + contact.phone);
			}
			});
			}
			});		
		*/
		
		return updateObject;
	} 
	else {
		return false;
	}
};

var isValidJSON = function(str) {
    try {
        JSON.parse(str);
	} 
	catch (e) {
        return false;
	}
    return true;
}


